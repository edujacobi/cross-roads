const Discord = require("discord.js");
exports.run = async (bot, message, args) => {
	let opt = ["faca", "9mm", "tec9", "rifle", "mp5", "ak47", "m4", "rpg", "oculos", "colete", "minigun"];
	let nome = ["Faca", "9mm", "Tec9", "Rifle", "Mp5", "AK-47", "M4", "RPG", "Óculos V Noturna", "Colete", "Minigun"];
	let atk = [10, 20, 30, 45, 40, 50, 60, 70, 10, 0, 80];
	let def = [5, 10, 15, 15, 20, 25, 35, 40, 50, 70, 55];
	let thumb = ["knife", "9mm", "tec9", "rifle", "mp5", "ak47", "M4", "rpg", "goggles", "colete", "minigun"];
	let utilidade = [
		"**Trabalho:** Açougueiro\n**Roubo:** Velhinha na esquina",
		"**Trabalho:** Vigilante\n**Roubo:** Mercearia do Zé",
		"**Trabalho:** Segurança Particular\n**Roubo:** Posto de gasolina",
		"**Trabalho:** Caçador de corno",
		"**Trabalho:** Treinador de Milícia",
		"**Trabalho:** Mercenário\n**Roubo:** Banco da cidade",
		"**Trabalho:** Rei do Crime",
		"**Trabalho:** Homem-bomba\n**Roubo:** Mafia Nyanista",
		"**Trabalho:** Espião da Ordem",
		"",
		"**Trabalho:** Godfather da Mafia Nyanista",
	]

	if (!args[0]) {
		const embed = new Discord.RichEmbed()
			.setTitle("Informações de Armas")
			.setThumbnail(bot.guilds.get('529674666692837378').emojis.find('name', 'fist').url)
			.setDescription("As seguintes armas estão disponíveis:")
			.setColor(message.member.displayColor)
			.addField(" 󠀀󠀀",
				`${bot.config.knife} Faca\n` +
				`${bot.config._9mm} 9mm\n` +
				`${bot.config.tec9} Tec9\n` +
				`${bot.config.rifle} Rifle\n` +
				`${bot.config.mp5} Mp5\n` +
				`${bot.config.ak47} AK-47`, true)
			.addField(" 󠀀󠀀",
				`${bot.config.m4} M4\n` +
				`${bot.config.rpg} RPG\n` +
				`${bot.config.goggles} Óculos V Noturna\n` +
				`${bot.config.colete} Colete\n` +
				`${bot.config.minigun} Minigun`, true)
			.setFooter(message.author.username, message.member.user.avatarURL)
			.setTimestamp();
		message.channel.send({
			embed
		});

	} else if (opt.indexOf(args[0]) > -1) {
		i = opt.indexOf(args[0])
		const embed = new Discord.RichEmbed()
			.setTitle("Informações de " + nome[i])
			.setThumbnail(bot.guilds.get('529674666692837378').emojis.find('name', thumb[i]).url)
			.setDescription(`**ATK** +${atk[i]}\n**DEF** +${def[i]}\n${utilidade[i]}`)
			.setColor(message.member.displayColor)
			.setFooter(message.author.username, message.member.user.avatarURL)
			.setTimestamp();
		message.channel.send({
			embed
		});

	} else
		return bot.createEmbed(message, "Esta arma não existe.")
};

exports.help = {
	name: "base",
	category: "Code",
	description: "base",
	usage: "base",
	example: "base"
};