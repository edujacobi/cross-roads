exports.run = async (bot, message, args) => {
    /*uData = bot.data.get(message.author.id)
	if (parseFloat(uData.moni) < args[0]) {
        return bot.createEmbed(message, `Você não tem ${bot.config.coin} suficiente para esta doação.`);
    } else if (args[0] < 0 || (args[0] % 1 != 0 || args[0] == "")) {
        return bot.createEmbed(message, "O valor inserido não é válido.");
    }
    
    let member = message.mentions.members.first();
    personData = bot.data.get(member.id);
    personData.moni += parseInt(args[0]);
    uData.moni -= parseInt(args[0]);
    bot.createEmbed(message, "Você doou " + args[0] + bot.config.coin + " para " + member.user.username);
    bot.data.set(message.author.id,uData);
    bot.data.set(member.id,personData);*/
}
