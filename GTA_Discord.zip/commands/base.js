exports.run = async (bot, message, args) => {
  
};

exports.help = {
  name: "base",
  category: "Code",
  description: "base",
  usage: "base",
  example: "base"
};