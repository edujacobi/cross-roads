exports.run = async (bot, message, args) => {
  uData = bot.data.get(message.author.id);
  if (uData.presente == -2)
    return bot.createEmbed(message, "Você já recebeu o seu presente.");
  
    else {
    uData.moni = uData.moni + 2000;
    uData.ficha = uData.ficha + 20;
    uData.presente = -2;
    bot.createEmbed(message, `Você recebeu 2000${bot.config.coin} e 20 ${bot.config.ficha}!`);
  }
  bot.data.set(message.author.id, uData);
};

exports.help = {
  name: "base",
  category: "Code",
  description: "base",
  usage: "base",
  example: "base"
};