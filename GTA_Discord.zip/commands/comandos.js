const Discord = require("discord.js");

exports.run = async (bot, message, args) => { //refazer pra ficar menor, separar em categorias
    const embed = new Discord.RichEmbed()
		.setTitle(bot.config.spray + " Comandos do Grand Theft Auto: Discord")
    .setDescription("Comandos que podem ser utilizados no bot")
		.setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/529168804291280897/GTAD.png")
		.setColor(message.member.displayColor)
		.addField(bot.config.ammugun + " Comprar",     "`" + bot.config.prefix + "loja` : Abre a loja\n`" 
									 + bot.config.prefix + "comprar [ID do item]` : Compra um item da loja pelo ID\n`"
									 + bot.config.prefix + "mercadonegro` : Produtos ilegais e trabalhos perigosos")
									  
		.addField(bot.config.bulldozer + " Trabalhar",   "`" + bot.config.prefix + "jobs` : Abre a lista de trabalhos\n`" 
								     + bot.config.prefix + "job [ID do job]` : Inicia um trabalho pelo ID\n`" 
								     + bot.config.prefix + "parar` : Interrompe o trabalho\n`" 
									 + bot.config.prefix + "receber` : Recebe o pagamento correspondente ao trabalho")

		.addField(bot.config.propertyG + " Investir", 	 "`" + bot.config.prefix + "investimentos` : Abre a lista de investimentos\n`" 
									 + bot.config.prefix + "investir [ID do investimento]` : Compra um investimento\n`" 
									 + bot.config.prefix + "investir parar` : Abandona o investimento atual\n`" 
									 + bot.config.prefix + "receber` : Recebe lucro referente ao tempo de investimento")
									 
		.addField(bot.config.emmetGun + " Roubar",      "`" + bot.config.prefix + "roubar info` : Vê maiores informações sobre os roubos\n`"
									 + bot.config.prefix + "roubar pessoa [jogador]` : Tenta assaltar um jogador\n`"
									 + bot.config.prefix + "roubar lugar [ID]` : Tenta assaltar um lugar\n`"
									 + bot.config.prefix + "roubar` : Vê sua situação")

		.addField(bot.config.police + " Prisão",      "`" + bot.config.prefix + "prisao` : Vê os jogadores presos e procurados do servidor\n`"
									 + bot.config.prefix + "prisao fugir` : Tenta fugir da prisão.\n`"
									 + bot.config.prefix + "prisao subornar [valor]` : Tenta subornar os guardas.")

		.addField(bot.config.car + " Informações", "`" + bot.config.prefix + "topgrana [total]` : Abre o rank até um top definido (opcional)\n`" 
									 + bot.config.prefix + "topserver` : Mostra o rank de servidores\n`"
									 + bot.config.prefix + "inv [jogador]` : Abre o inventário e status do jogador\n`"
									 + bot.config.prefix + "arma [nome]` : Mostra informações sobre uma arma")

		.addField(bot.config.dateDrink + " Utilidades",  "`" + bot.config.prefix + "daily` : Recebe 500 diários\n`" 
									 + bot.config.prefix + "stats` : Mostra informações sobre o bot\n`"
									 + bot.config.prefix + "ping` : Verifica a latência do bot\n`"
									 + bot.config.prefix + "presente` : Recebe um presente para iniciar o jogo")			

		.addField(bot.config.mafiaCasino + " Jogatina",    "`" + bot.config.prefix + "cassino` : Mais explicações sobre os jogos\n`"
									 + bot.config.prefix + "bet [cara | coroa] [valor]` : Aposta um valor em cara ou coroa\n`" 
									 + bot.config.prefix + "cambio [quantidade]` : Troca suas fichas por coins\n`" 
									 + bot.config.prefix + "niquel` : Jogo de caça-níquel com fichas\n`"
									 + bot.config.prefix + "galo info` : Informação sobre os galos e rinhas\n`"
									 + bot.config.prefix + "roleta [número] [valor]` : Joga a roleta. Números de 0 a 36")
		.setFooter(message.author.username, message.member.user.avatarURL)
		.setTimestamp();
    message.channel.send({embed})
}
