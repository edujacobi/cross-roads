const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
  let currTime = new Date().getTime();
  let dia = new Date().getDay(); 
  let option = args[0];

  if (dia == 0 || dia == 6) {
    if (!option) {
      const embed = new Discord.RichEmbed()

        .setTitle(bot.config.thetruth + " Mercado Negro")
        .setDescription("Olha só essas belezinhas")
        //.setThumbnail("https://cdn.discordapp.com/attachments/531174573463306240/535604989972840448/minigunicon.png")
        .setColor(message.member.displayColor)

        .addField(`1: ${bot.config.minigun} Minigun`, `Preço: 10.000.000 ${bot.config.coin} \nATK +80\nDEF +55` + "\n`;mercadonegro 1`", true)
        .addField(`2: ${bot.config.ficha} 1000 Fichas`, `Preço: 95.000 ${bot.config.coin} \n5% de desconto` + "\n`;mercadonegro 2`", true)
        .addField("3: Godfather da Mafia Nyanista",     `Tempo: 72h \nSalário: 15.000.000 ${bot.config.coin}\nNecessário: ${bot.config.minigun}` + "\n`;job 13`")

        .setFooter(message.author.username, message.member.user.avatarURL)
        .setTimestamp();
      message.channel.send({
        embed
      })

    } else {
      uData = bot.data.get(message.author.id);
      let prices = [10000000, 95000];

      if (option < 1 || (option % 1 != 0) || option > prices.length)
        return bot.createEmbed(message, `O ID deve ser de 1 a ${prices.length}.`);

      else if (uData.moni < prices[option - 1])
        return bot.createEmbed(message, `Você não possui ${bot.config.coin} suficiente para comprar este item.`);

      uData.moni -= prices[option - 1];
      uData.lojaGastos += prices[option - 1];

      switch (parseInt(option)) {
        case 1:
          if (!bot.data.has(message.author.id, "_minigun")){
            uData._minigun = 0;
            bot.data.set(message.author.id, uData);
          }

          uData._minigun = (uData._minigun > currTime ? uData._minigun + 259200000 : currTime + 259200000);
          bot.createEmbed(message, message.author.username + " comprou uma Minigun " + bot.config.minigun + ".");
          break;

        case 2:
          uData.ficha = uData.ficha + 1000;
          bot.createEmbed(message, message.author.username + " comprou 1000 Fichas " + bot.config.ficha + ".");
          break;
      }
      bot.data.set(message.author.id, uData);
    }

  } else 
    return bot.createEmbed(message, "Hey, psiu... Volta aqui mais tarde que vou ter uma oferta bem bacaninha pra você.")

};

exports.help = {
  name: "base",
  category: "Code",
  description: "base",
  usage: "base",
  example: "base"
};