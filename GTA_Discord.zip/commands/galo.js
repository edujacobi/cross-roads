const Discord = require("discord.js");
exports.run = async (bot, message, args) => {

  uData = bot.data.get(message.author.id);
  uID = message.author.id;
  let target = message.mentions.members.first();
  let time = new Date().getTime();
  let option = args[0];
  let aposta = args[1];

  if (uData.galo == 0 || !bot.data.has(message.author.id, "galo")) { // se o user nao tem galo ainda
    uData.galo = 1;
    uData.galoPower = 30; // 30% de chance de vitória no lvl 1
    uData.tempoRinha = 0; // Tempo para prox rinha = 0
    bot.data.set(message.author.id, uData);
    return bot.createEmbed(message, "Você recebeu um galo! :rooster:");
  }

  if (!target) {
    if (!option) { // mostrar info do galo 
      let t = Math.floor((uData.tempoRinha - time) / 1000 / 60);
      const embed = new Discord.RichEmbed()
        .setTitle((bot.data.has(message.author.id, "galoNome") ? `Galo "${uData.galoNome}" de ${uData.nome} :rooster:` : `Galo de ${uData.nome} :rooster:`)) // se o galo nao tem nome, aparecerá somente "Galo"
        .setDescription((uData.galoTit == undefined ? "**Título:** Garnizé" : `**Título:** ${uData.galoTit}`) +
          `\n**Nível: **${uData.galoPower - 30}` +
          `\n**Chance de vitória: **${uData.galoPower}%` +
          (t < 0 ? "\n**Pronto pra peleia**" : `\n**Tempo até descansar: ** ${t} minutos`))
        .setThumbnail("https://cdn.discordapp.com/attachments/529674667414519810/530191738690732033/unknown.png")
        .setColor(message.member.displayColor)
        //.addField("Stats", "**ATK**: 0/10 | **DEF**: 0/10\n**SPD**: 0/10 | **RES**: 0/10")

        .setFooter(message.author.username, message.member.user.avatarURL)
        .setTimestamp();
      return message.channel.send({
        embed
      });

    } else if (option == "nome") { // setar nome
      if (!args[1]) {
        return bot.createEmbed(message, "Insira um nome para seu galo! :rooster:");

      } else {
        let nome = args.join(" ").replace(args[0], "");
        nome = nome.substring(1, nome.length);

        if (nome.length > 20)
          return bot.createEmbed(message, "O nome escolhido é muito grande, escolha um menor. :rooster:");

        else {
          let nome = args.join(" ").replace(args[0], "");
          nome = nome.substring(1, nome.length);
          uData.galoNome = nome;
          bot.data.set(message.author.id, uData);
          return bot.createEmbed(message, `Você nomeou seu galo como **${uData.galoNome}**! :rooster:`);
        }
      }

    } else if (option == "titulo") { // setar titulo
      if (!args[1]) {
        return bot.createEmbed(message, "Insira um título para seu galo! :rooster:");

      } else {
        let titulo = args.join(" ").replace(args[0], "");
        titulo = titulo.substring(1, titulo.length);

        if (titulo.length > 20)
          return bot.createEmbed(message, "O título escolhido é muito grande, escolha um menor. :rooster:");

        else {
          let titulo = args.join(" ").replace(args[0], "");
          titulo = titulo.substring(1, titulo.length);
          uData.galoTit = titulo;
          bot.data.set(message.author.id, uData);
          return bot.createEmbed(message, `Você deu o título de **${uData.galoTit}** para seu galo! :rooster:`);
        }
      }

    } else if (option == "info") { // ter infos sobre os galos

      const embed = new Discord.RichEmbed()
        .setTitle("Informações sobre os galos")
        .setThumbnail("https://cdn.discordapp.com/attachments/529674667414519810/530616556518899722/unknown.png")
        .setColor(message.member.displayColor)
        .addField("Como funciona", "Você recebeu um galo de combate!\n" +
          "Ele começa no nível 0 e avançará 1 nível ao ganhar uma luta.\n" +
          "Do nível 30 em diante, seu galo perderá níveis se perder as lutas.\n" +
          "O nível máximo que ele pode atingir é 40.\n" +
          `Você pode comprar ${bot.config.whey} **Whey Protein** na loja, que aumenta o nível dele em 1.\n` +
          "O valor do Whey aumenta com base no nível do seu galo.\n" +
          "Após cada luta, seu galo precisará descansar por 30min para se recuperar.")

        .addField("Comandos", "`;galo (usuário)` Vê informações sobre um galo\n" +
          "`;galo nome [novo-nome]` Escolhe um nome para seu galo\n" +
          "`;galo titulo [novo-titulo]` Escolhe um título para seu galo\n" +
          "`;galo rinha [valor] [usuário]` Desafia um usuário para uma rinha.\n")

        .setFooter(message.author.username, message.member.user.avatarURL)
        .setTimestamp();
      return message.channel.send({
        embed
      });

    }
  } else if (option == "rinha") { // desafiar outros players

    if (!target) {
      bot.createEmbed(message, "Você deve escolher uma pessoa para desafiar. :rooster:")

    } else {
      let alvo = target.user;
      let tData = bot.data.get(alvo.id);
      let userT = tData;
      let userD = uData;

      if (!userT)
        return bot.createEmbed(message, "Este usuário não tem um galo. :rooster:");

      if (message.author.id == target.id)
        return bot.createEmbed(message, "Seu galo não pode ir para a rinha sozinho. :rooster:");

      if (userD.tempoRinha > time) {
        let t = Math.floor((userD.tempoRinha - time) / 1000 / 60);
        return bot.createEmbed(message, `Seu galo está descansando. Ele estará pronto para outra briga em ${t} minutos. :rooster:`);
      }
      if (userT.tempoRinha > time) {
        let t = Math.floor((userT.tempoRinha - time) / 1000 / 60);
        return bot.createEmbed(message, `O galo de **${userT.nome}** está descansando. Ele estará pronto para outra briga em ${t} minutos. :rooster:`);
      }

      if (userD.moni < 1)
        return bot.createEmbed(message, `Você não tem ${bot.config.coin} suficiente para apostar.`);

      else if (userT.preso > time) {
        let tt = Math.floor((userT.preso - time) / 1000 / 60);
        return bot.createEmbed(message, `${userT.nome} não pode apostar enquanto estiver preso. Sairá após ${bot.minToHour(tt)}. :clock230: `);

      } else if (uData.preso > time) {
        let tt = Math.floor((uData.preso - time) / 1000 / 60);
        return bot.createEmbed(message, `Você não pode apostar enquanto estiver preso. Sairá após ${bot.minToHour(tt)}. :clock230: `);

      } else if (aposta <= 0 || (aposta % 1 != 0))
        return bot.createEmbed(message, "O valor inserido não é válido.");

      /*else if (aposta > 100000)
        return bot.createEmbed(message, `O valor máximo de apostas é 100000${bot.config.coin}.`);*/

      else if (userT.moni < 1)
        return bot.createEmbed(message, `**${userT.nome}** não tem ${bot.config.coin} suficiente para apostar.`);

      else {
        if (parseFloat(userD.moni) < aposta)
          return bot.createEmbed(message, "Você não tem esse valor para apostar.");

        if (parseFloat(userT.moni) < aposta)
          return bot.createEmbed(message, `**${userT.nome}** não tem esse valor para apostar.`);

        bot.createEmbed(message, `**${userD.nome}** desafiou **${userT.nome}** para uma rinha 1x1 valendo ${parseInt(aposta).toLocaleString().replace(/,/g, ".")}${bot.config.coin}. \n` + "Responda `aceitar` ou ignore.")
          .then(() => {
            message.channel.awaitMessages(response => response.content === 'aceitar' && response.author.id == alvo.id, {
                max: 1,
                time: 30000,
                errors: ['time'],
              })
              .then(() => {
                bot.createEmbed(message, `**${userT.nome}** aceitou o desafio!`);

                let random1 = bot.getRandom(1, 100);
                let random2 = bot.getRandom(1, 100);

                let fight = (random1 * userD.galoPower > random2 * userT.galoPower ? "u" : "t");

                let textos_inicio = [
                  `**${userD.galoNome}** começa a luta atacando **${userT.galoNome}** no queixo!`,
                  `**${userT.galoNome}** começa a luta atacando **${userD.galoNome}** no queixo!`,
                  `**${userT.galoNome}** provoca **${userD.galoNome}** chamando ele de galinha!`,
                  `**${userD.galoNome}** provoca **${userT.galoNome}** chamando ele de galinha!`,
                  `**${userD.galoNome}** falou que é filho do Caramuru!`,
                  `**${userT.galoNome}** falou que é filho do Caramuru!`,
                  `**${userD.galoNome}** disse que quem toma Whey pra subir de nível é pinto pequeno!`,
                  `**${userT.galoNome}** disse que quem toma Whey pra subir de nível é pinto pequeno!`,
                  `**${userD.galoNome}** disse que é rinha igual bumerangue, tudo que vai, volta.`,
                  `**${userT.galoNome}** disse que é rinha igual bumerangue, tudo que vai, volta.`
                ]
                
                let textos_luta = [
                  `**${userD.galoNome}** voou por incríveis 2 segundos e deixou **${userT.galoNome}** perplecto!`,
                  `**${userT.galoNome}** ciscou palha no olho de **${userD.galoNome}** e aproveitou para um ataque surpresa!`,
                  `**${userD.galoNome}** arrancou o olho de **${userT.galoNome}**! Por sorte era o olho ruim.`,
                  `**${userT.galoNome}** deu um rasante em **${userD.galoNome}** arrancando várias de suas penas!`,
                  `**${userD.galoNome}** acertou um combo de 5 hits em **${userT.galoNome}**!`,
                  `**${userT.galoNome}** aproveitou que **${userD.galoNome}** olhou para uma galinha e deu um mortal triplo carpado!`,
                  `**${userD.galoNome}** usou um golpe especial e **${userT.galoNome}** ficou sem entender nada!`,
                  `**${userT.galoNome}** apanha bastante, mas mostra para **${userD.galoNome}** que pau que nasce torto tanto bate até que fura!`,
                  `**${userD.galoNome}** rasga o peito de **${userT.galoNome}** como se fosse manteiga!`,
                  `**${userT.galoNome}** tentou usar *Raio Destruidor da Morte* em **${userD.galoNome}**, mas acaba errando.`,
                  `**${userD.galoNome}** tenta acertar um *Fogo Sagrado da Conflagração* em **${userT.galoNome}**, erra por pouco e acerta a plateia!`,
                  `**${userT.galoNome}** está paralizado e não consegue se mover!`,
                  `**${userD.galoNome}** se sente lento e acaba errando diversos ataques.`,
                  `A Polícia Federal adentra no recinto e todos ficam em pânico. Um dos policiais fala: "APOSTO MIL NO **${userT.galoNome}**"!`,
                  `Pouco se importando com as regras, **${userD.galoNome}** pega uma ${bot.config._9mm} 9mm e atira em **${userT.galoNome}**.`,
                  `**${userT.galoNome}** utiliza um *Z-Move* com **${userT.nome}**, causando dano crítico em **${userD.galoNome}**!`,
                  `**${userD.galoNome}** utiliza um *Z-Move* com **${userD.nome}** em **${userT.galoNome}**. É super efetivo!`,
                  `**${userT.galoNome}** usa a técnica do *Golpe do Dedo Ushi*, mas **${userD.galoNome}** aproveita a abertura e desce a porrada.`,
                  `Após receber diversos golpes, **${userD.galoNome}** está atordoado, mas ainda continua de pé!`
                ]

                bot.shuffle(textos_luta);

                //gera textos de batalha
                const msg1 = new Discord.RichEmbed({
                  description: textos_inicio[Math.floor(Math.random() * textos_inicio.length)],
                  color: 0x36393e
                })
                setTimeout(function () {
                  (message.channel.send(msg1))
                }, 1000);

                if (userD.galoPower == userT.galoPower) {
                  const msg2 = new Discord.RichEmbed({
                    description: `**${userD.galoNome}** não sabe como atacar **${userT.galoNome}**! Eles já estão parados se encarando por 5 minutos!`,
                    color: 0x36393e
                  })
                  const msg3 = new Discord.RichEmbed({
                    description: `A única diferença entre **${userT.galoNome}** e **${userD.galoNome}** é o nome! Ambos são incrivelmente habilidosos!`,
                    color: 0x36393e
                  })
                  setTimeout(function () {
                    (message.channel.send(random1 >= random2 ? msg2 : msg3))
                  }, 5000);

                } else {
                  const msg4 = new Discord.RichEmbed({
                    description: textos_luta[0],
                    color: 0x36393e
                  })
                  setTimeout(function () {
                    (message.channel.send(msg4))
                  }, 5000);
                }

                const msg5 = new Discord.RichEmbed({
                  description: textos_luta[1],
                  color: 0x36393e
                })
                setTimeout(function () {
                  (message.channel.send(msg5))
                }, 9000);

                const msg6 = new Discord.RichEmbed({
                  description: textos_luta[2],
                  color: 0x36393e
                })
                setTimeout(function () {
                  (message.channel.send(msg6))
                }, 14000);

                const msg7 = new Discord.RichEmbed({
                  description: textos_luta[3],
                  color: 0x36393e
                })
                setTimeout(function () {
                  (message.channel.send(msg7))
                }, 19000);

                const msg8 = new Discord.RichEmbed({
                  description: (random1 >= random2 ? `**${userD.galoNome}** está implacável e **${userT.galoNome}** já não resiste mais!` :   `**${userT.galoNome}** sabe que sua derrota foi digna e vai ao chão!`),
                  color: 0x36393e
                })
                const msg9 = new Discord.RichEmbed({
                  description: (random1 >= random2 ? `Os golpes de **${userT.galoNome}** são certeiros e **${userD.galoNome}** está ciente de sua derrota!` : `**${userD.galoNome}** cai na lona com um sorriso no rosto, pois sabe que deu o seu melhor.`),
                  color: 0x36393e
                })
                setTimeout(function () {
                  (message.channel.send(fight == 'u' ? msg8 : msg9))
                }, 24000);

                if (fight == "u") {
                  if (userD.galoPower >= 70) {
                    userD.moni += parseInt(aposta);
                    userT.moni -= parseInt(aposta);
                    userD.betW++;
                    userT.betL++;
                    setTimeout(function () {
                      (bot.createEmbed(message, `**${userD.galoNome}** venceu a rinha contra **${userT.galoNome}** e **${userD.nome}** recebeu ${parseInt(aposta).toLocaleString().replace(/,/g, ".")}${bot.config.coin}!` +
                        "\nEle está no nível 40, e não poderá upar mais! :rooster:"))
                    }, 26000);

                  } else {
                    userD.galoPower++;
                    if (userT.galoPower >= 60)
                      userT.galoPower -= 1;
                    userD.moni += parseInt(aposta);
                    userT.moni -= parseInt(aposta);
                    userD.betW++;
                    userT.betL++;
                    setTimeout(function () {
                      (bot.createEmbed(message, `**${userD.galoNome}** venceu a rinha contra **${userT.galoNome}** e **${userD.nome}** ganhou ${parseInt(aposta).toLocaleString().replace(/,/g, ".")}${bot.config.coin}!` +
                        `\n**${userD.galoNome}** subiu para o nível ${userD.galoPower - 30}! :rooster:`))
                    }, 26000);
                  }

                } else {
                  if (userT.galoPower >= 70) {
                    userT.moni += parseInt(aposta);
                    userD.moni -= parseInt(aposta);
                    userT.betW++;
                    userD.betL++;
                    setTimeout(function () {
                      (bot.createEmbed(message, `**${userT.galoNome}** venceu a rinha contra **${userD.galoNome}** e **${userT.nome}** ganhou ${parseInt(aposta).toLocaleString().replace(/,/g, ".")} ${bot.config.coin}!` +
                        `\n**${userT.galoNome}** está no nível 40, e não poderá upar mais! :rooster:`))
                    }, 26000);

                  } else {
                    userT.galoPower++;
                    if (userD.galoPower >= 60)
                      userD.galoPower -= 1;
                    userT.moni += parseInt(aposta);
                    userD.moni -= parseInt(aposta);
                    userT.betW++;
                    userD.betL++;
                    setTimeout(function () {
                      (bot.createEmbed(message, `**${userT.galoNome}** venceu a rinha contra **${userD.galoNome}** e **${userT.nome}** ganhou ${parseInt(aposta).toLocaleString().replace(/,/g, ".")}${bot.config.coin}!` +
                        `\n**${userT.galoNome}** subiu para o nível ${userT.galoPower - 30}! :rooster:`))
                    }, 26000);
                  }
                }

                userD.tempoRinha = time + 1800000;
                userT.tempoRinha = time + 1800000;
                bot.data.set(uID, userD);
                bot.data.set(target.id, userT);

                setTimeout(function () {
                  (message.reply(`<@${target.id}>, seus galos estão prontos para mais uma feroz batalha! :rooster:`))
                }, userD.tempoRinha - time);
              })

              .catch(() => {
                bot.createEmbed(message, `**${userT.nome}** não respondeu. Ou ele está offline ou é um frangote.`);
              });
          });
      }
    }

  } else { // mostra info do galo do target
    let tData = bot.data.get(target.id)
    let t = Math.floor((tData.tempoRinha - time) / 1000 / 60);

    const embed = new Discord.RichEmbed()
      .setTitle((tData.galoNome == undefined ? `Galo de ${tData.nome} :rooster:` : `Galo "${tData.galoNome}" de ${tData.nome} :rooster:`))
      .setDescription((tData.galoTit == undefined ? "**Título:** Garnizé" : `**Título:** ${tData.galoTit}`) +
        `\n**Nível: ** ${tData.galoPower - 30}` +
        `\n**Chance de vitória: ** ${tData.galoPower}%` +
        (t < 0 ? "\n**Pronto pra peleia**" : `\n**Tempo até descansar: ** ${t} minutos`))
      .setThumbnail("https://cdn.discordapp.com/attachments/529674667414519810/530191738690732033/unknown.png")
      .setColor(message.member.displayColor)
      //.addField("Stats", "**ATK**: 0/10 | **DEF**: 0/10\n**SPD**: 0/10 | **RES**: 0/10")
      .setFooter(message.author.username, message.member.user.avatarURL)
      .setTimestamp();

    return message.channel.send({
      embed
    });

  }
  bot.data.set(message.author.id, uData);
};