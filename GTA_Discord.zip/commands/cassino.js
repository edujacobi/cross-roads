const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
	const embed = new Discord.RichEmbed()

		.setTitle(bot.config.mafiaCasino + " Grand Theft Auto: Discord Cassino")
		.setDescription("Aposte, ganhe, perca, quebre a banca!\nAqui você poderá apostar suas fichas ou seu dinheiro!")
		.setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/529390152309538816/cassino-chip.png")
		.setColor(message.member.displayColor)
		.addField("Fichas", "Compre fichas na loja e utilize elas na máquina caça-níqueis e na roleta!")
		.addField("Cara ou Coroa", "Apostando um valor em coins, você tem 50% de chance de ganhar ou perder!\n" +
			"`" + bot.config.prefix + "bet [cara | coroa] [valor]`")
		.addField("Rinha de galos", "Seu galo começa no nível 0, e a cada vitória, ele aumenta 1 nível. Cada nível aumenta ainda mais a chance de vitória dele.\n" +
			"Após cada luta, seu galo deve descansar por 45min. O valor máximo de aposta é 100,000.\n" +
			"`" + bot.config.prefix + "galo info`")
		.addField("Máquina Caça-níqueis", "Acerte um trio e ganhe 150!\nACERTE UM TRIO DE <:cash:529880352143966258> E GANHE 500!\n" +
			"`" + bot.config.prefix + "niquel`")
		.addField("Roleta", "Aposte em um número e torça para cair no seu! Você ganha 36 vezes o valor apostado! Escolha números de 0 a 36.\n" +
			"`" + bot.config.prefix + "roleta [número] [valor]`")
		.addField("Câmbio", "Troque suas fichas por coins! Cada ficha vale 90" + bot.config.coin + ".\n" +
			"`" + bot.config.prefix + "cambio [quantidade]`")
		.setFooter(message.author.username, message.member.user.avatarURL)
		.setTimestamp();
	message.channel.send({
		embed
	});
}