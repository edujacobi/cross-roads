exports.run = async (bot, message, args) => {
	let time = new Date().getTime();
	let uData = bot.data.get(message.author.id);
	if (uData.job >= 0) return bot.createEmbed(message, "You can't bet while working. " + bot.config.bulldozer);

	if (uData.preso > time) {
		let t = Math.floor((uData.preso - time) / 1000 / 60);
		return bot.createEmbed(message, `You can't bet while arrested. Leave after ${bot.minToHour(t)} minutes. :clock230: `);
	}

	if (uData.moni < 1)
		return bot.createEmbed(message, `You don't have enough ${bot.config.coin} to bet.`);

	else if (args[1] <= 0 || (args[1] % 1 != 0))
		return bot.createEmbed(message, "The inserted value is invalid.");

	else if (args[0] == "heads" || args[0] == "tails") {
		message.delete();
		
		if (parseFloat(uData.moni) < args[1])
			return bot.createEmbed(message, "You don't have this amount to bet.");

		let flip;

		// _jetpack = sorte +10%
		if (uData._jetpack > time)
			flip = (bot.getRandom(0, 100) < 55 ? args[0] : (args[0] == "heads" ? "tails" : "head"));
		else
			flip = (bot.getRandom(0, 100) < 50 ? "heads" : "tails");


		if (args[0] == flip) {
			uData.moni += parseInt(args[1]);
			uData.betW++;
			bot.createEmbed(message, `You **win** ${parseInt(args[1]).toLocaleString().replace(/,/g, ".")} and still have ` + (uData.moni.toLocaleString().replace(/,/g, ".")) + bot.config.coin + ".");
		} else {
			uData.moni -= parseInt(args[1]);
			uData.betL++;
			bot.createEmbed(message, `You **lose** ${parseInt(args[1]).toLocaleString().replace(/,/g, ".")} and still have  ` + (uData.moni.toLocaleString().replace(/,/g, ".")) + bot.config.coin + ".");
		}
	} else {
		bot.createEmbed(message, "You should bet on heads or tails.");
		return;
	}
	bot.data.set(message.author.id, uData);
}