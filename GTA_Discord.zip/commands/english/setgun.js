exports.run = async (bot, message, args) => {
	let currTime = new Date().getTime();

	if (message.author.id != bot.config.adminID) return;

	else {
		let _12horas = 43200000;
		let member = message.mentions.members.first();
		uData = bot.data.get(member.id);
		arma = args[0];

		if (arma == 'knife')
			uData._knife = (uData._knife > currTime ? uData._knife + _12horas : currTime + _12horas);

		else if (arma == '9mm')
			uData._9mm = (uData._9mm > currTime ? uData._9mm + _12horas : currTime + _12horas);

		else if (arma == 'tec9')
			uData._tec9 = (uData._tec9 > currTime ? uData._tec9 + _12horas : currTime + _12horas);

		else if (arma == 'rifle')
			uData._rifle = (uData._rifle > currTime ? uData._rifle + _12horas : currTime + _12horas);

		else if (arma == 'mp5')
			uData._mp5 = (uData._mp5 > currTime ? uData._mp5 + _12horas : currTime + _12horas);

		else if (arma == 'ak47')
			uData._ak47 = (uData._ak47 > currTime ? uData._ak47 + _12horas : currTime + _12horas);

		else if (arma == 'm4')
			uData._m4 = (uData._m4 > currTime ? uData._m4 + _12horas : currTime + _12horas);

		else if (arma == 'colete')
			uData._colete = (uData._colete > currTime ? uData._colete + _12horas : currTime + _12horas);

		else if (arma == 'jetpack')
			uData._jetpack = (uData._jetpack > currTime ? uData._jetpack + _12horas : currTime + _12horas);

		else if (arma == 'minigun')
			uData._minigun = (uData._minigun > currTime ? uData._minigun + _12horas : currTime + _12horas);

		else if (arma == 'rpg')
			uData._rpg = (uData._rpg > currTime ? uData._rpg + _12horas : currTime + _12horas);

		else if (arma == 'goggles')
			uData._goggles = (uData._goggles > currTime ? uData._goggles + _12horas : currTime + _12horas);

		else 
			return bot.createEmbed(message, "Arma inválida.")

		imgArma = bot.config[arma];
		console.log(imgArma);
		bot.createEmbed(message, `${member.user.username} recebeu 12h de ${imgArma}.`);	
		bot.data.set(member.user.id, uData);
	}
};

exports.help = {
	name: "base",
	category: "Code",
	description: "base",
	usage: "base",
	example: "base"
};