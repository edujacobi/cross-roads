const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
  if (message.author.id != bot.config.adminID) {
    return;

  } else {
    /*if (!args || args.length < 1)
      return bot.createEmbed(message, "Informe um comando.");

    if (!bot.commands.get(args[0]))
      return bot.createEmbed(message, "Comando não encontrado.")

    let response = await bot.unloadCommand(args[0]);

    if (response)
      return bot.createEmbed(message, `Erro ao descarregar: ${response}`);

    response = bot.loadCommand(args[0]);

    if (response)
      return bot.createEmbed(message, `Erro ao carregar: ${response}`);

    bot.createEmbed(message, `O comando \`${args[0]}\` foi recarregado`);*/

    if (!args || args.size < 1)
    return message.channel.send(new Discord.RichEmbed({
      description: "Informe um comando a ser recarregado.",
      color: 0x36393e
  }))

    const commandName = args[0];
    // Check if the command exists and is valid
    if (!bot.commands.has(commandName)) {
      return message.channel.send(new Discord.RichEmbed({
        description: "O comando não existe.",
        color: 0x36393e
    }))
    }
    // the path is relative to the *current folder*, so just ./filename.js
    delete require.cache[require.resolve(`./${commandName}.js`)];
    // We also need to delete and reload the command from the bot.commands Enmap
    bot.commands.delete(commandName);
    const props = require(`./${commandName}.js`);
    bot.commands.set(commandName, props);

    message.channel.send(new Discord.RichEmbed({
      description: `O comando \`${commandName}\` foi recarregado.`,
      color: 0x36393e
    }))
  }
};

exports.help = {
  name: "reload",
  category: "Code",
  description: "Reloads a command that\'s been modified.",
  usage: "reload [command]",
  example: "reload eval"
};