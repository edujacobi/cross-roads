const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
    const embed = new Discord.RichEmbed()
    
        .setTitle(bot.config.bulldozer + " Empregos disponíveis")
        .setDescription("Você não poderá apostar ou roubar enquanto trabalha\n\n")
        //.setThumbnail("https://cdn.discordapp.com/attachments/462656263109476353/467340041937616926/TelefonoSanAndreasHD.png")
        .setColor(message.member.displayColor)
    
        .addField("1: Entregador de panfleto",       "Tempo: 1h\n" + "Salário: 220"  + bot.config.coin, true)
        .addField("2: Motoboy",                      "Tempo: 2h\n" + "Salário: 500"  + bot.config.coin, true)
        .addField("3: Pedreiro",                     "Tempo: 3h\n" + "Salário: 800"  + bot.config.coin, true)
        .addField("4: Açougueiro",                   "Tempo: 4h\n" + "Salário: 1.500" + bot.config.coin + "\nNecessário: " + bot.config.knife, true)
        .addField("5: Vigilante",                    "Tempo: 6h\n" + "Salário: 4.000" + bot.config.coin + "\nNecessário: " + bot.config._9mm, true)
        .addField("6: Segurança particular",         "Tempo: 8h\n" + "Salário: 8.000" + bot.config.coin + "\nNecessário: " + bot.config.tec9, true)
        .addField("7: Caçador de Corno",             "Tempo: 1h\n" + "Salário: 1.200" + bot.config.coin + "\nNecessário: " + bot.config.rifle, true)
        .addField("8: Treinador de milícia",         "Tempo: 12h\n" + "Salário: 20.000" + bot.config.coin + "\nNecessário: " + bot.config.mp5, true)
        .addField("9: Mercenário",                   "Tempo: 18h\n" + "Salário: 35.000" + bot.config.coin + "\nNecessário: " + bot.config.ak47, true)
        .addField("10: Rei do Crime",                "Tempo: 24h\n" + "Salário: 70.000" + bot.config.coin + "\nNecessário: " + bot.config.m4, true)
        .addField("11: Homem-bomba",                 "Tempo: 40h\n" + "Salário: 150.000" + bot.config.coin + "\nNecessário: " + bot.config.rpg, true)
        .addField("12: Espião da Ordem",             "Tempo: 60h\n" + "Salário: 1.000.000" + bot.config.coin + "\nNecessário: " + bot.config.goggles, true)
    
        .setFooter(message.author.username, message.member.user.avatarURL)
	    .setTimestamp();

    message.channel.send({embed})
}
