const Discord = require("discord.js");
const moment = require("moment");
require("moment-duration-format");

exports.run = (bot, message, args, level) => { 
  const embed = new Discord.RichEmbed();
  embed.setTitle(bot.config.dateDrink + " Estatísticas GTA Discord")
  .setThumbnail(bot.user.avatarURL)
  .setColor(message.member.displayColor)
  .addField("• Uso de Memória", `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`, true)
  .addField("• Tempo online", ` ${bot.minToHour(Math.floor(bot.uptime / 1000 / 60))}`, true)
  .addField("• Usuários", ` ${bot.data.indexes.length}`, true)
  .addField("• Servidores", ` ${bot.guilds.size.toLocaleString()}`, true)
  .addField("• Canais", ` ${bot.channels.size.toLocaleString()}`, true)
  .addField("• Discord.js", ` v${Discord.version}`, true)
  .addField("• NodeJS", ` ${process.version}`, true)
  .setFooter("Criador: Jacobi#5109 | Colaborador: idontknow#0001", bot.users.get('332228051871989761').avatarURL);

  message.channel.send({embed})
};

exports.help = {
  name: "stats",
  category: "Miscelaneous",
  description: "Gives some useful bot statistics",
  usage: "stats",
  example: "stats"
};