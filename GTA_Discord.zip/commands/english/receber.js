const Discord = require("discord.js");

let coolDowns = [3600000, 7200000, 10800000, 14400000, 21600000, 28800000, 3600000, 43200000, 64800000, 86400000, 144000000, 216000000, 259200000];
let semana = 604800000; // 7 dias
let hora = 3600000; // 1h

exports.run = async (bot, message, args) => {
	uData = bot.data.get(message.author.id);
	currTime = new Date().getTime();

	let salarios = [220, 500, 800, 1500, 4000, 8000, 1200, 20000, 35000, 70000, 150000, 1000000, 15000000];
	let lucros = [100, 550, 1725, 6000, 18750, 65000];

	linhaTrabalho = '';
	linhaInvest = '';

	if (uData.job < 0) {
		linhaTrabalho = "Você não tem nada para receber do seu trabalho.";

	} else if (currTime > (uData.jobTime + coolDowns[uData.job])) {
		linhaTrabalho = "Você recebeu seu pagamento de " + (salarios[uData.job].toLocaleString().replace(',', '.').replace(',', '.')) + bot.config.coin + ".";

		uData.moni += parseInt(salarios[uData.job]);
		uData.jobGanhos += parseInt(salarios[uData.job]);
		uData.job = -1;
		uData.jobTime = 0;

	} else
		linhaTrabalho = "Você ainda está trabalhando. " + bot.config.bulldozer;

	horas = (currTime - uData.investLast); // horário de início do investimento - o horário do ultimo saque = horas para sacar
	praSacar = Math.floor(((horas / hora) * lucros[uData.invest]));// pega valor decimal e multiplica pelo lucro por hora


	if (currTime < (uData.investTime + semana)) { //se o investimento ainda não completou uma semana
		linhaInvest = "Você recebeu " + (praSacar.toLocaleString().toLocaleString().replace(/,/g, ".")) + bot.config.coin + " de seu investimento.";

		uData.moni += parseInt(praSacar);
		uData.investGanhos += parseInt(praSacar);
		uData.investLast = currTime; 

	} else if (uData.invest != -1) { // se já passou uma semana
		linhaInvest = "Seu investimento acabou. Você recebeu " + (praSacar.toLocaleString().replace(/,/g, ".")) + bot.config.coin + " dele.";

		uData.moni += parseInt(praSacar);
		uData.investGanhos += parseInt(praSacar);
		uData.investLast = 0;
		uData.invest = -1;
		uData.investTime = 0;
	}

	const embed = new Discord.RichEmbed()
		.setColor(message.member.displayColor)
		.setFooter(message.author.username, message.member.user.avatarURL)
		.setTimestamp()
		.setDescription(linhaTrabalho + "\n" + linhaInvest)

	message.channel.send({
		embed
	});
	bot.data.set(message.author.id, uData)
}