exports.run = async (bot, message, args) => {
	if (message.author.id != bot.config.adminID) return;
	else {
		let member = message.mentions.members.first();
		personData = bot.data.get(member.id);
		valor = parseInt(args[0]);
		bot.createEmbed(message, `**${member.user.username}** ficou com ${args[0]}${bot.config.coin} em sua carteira.`);
		bot.data.set(member.id, valor, "moni");
	}
};

exports.help = {
	name: "base",
	category: "Code",
	description: "base",
	usage: "base",
	example: "base"
};