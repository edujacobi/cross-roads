const Discord = require("discord.js");
exports.run = async (bot, message, args) => {
    const embed = new Discord.RichEmbed()

        .setTitle(bot.config.saveGame + " Update 0.12")
        .setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/526265639552417802/GTD.png")
        .setColor(message.member.displayColor)
        .addField("Prisão!", "Veja os membros presos e procurados do servidor! `;prisao`")
        .addField("168 minutos são quantas horas?", "Agora os mostradores de tempo usam horas e minutos.")
        .addField("Inventário e Roubo sem ping", "Você pode ver o inventário de um usuário de outro servidor, bem como rouba-lo!")
        .addField("Rinhas, rinhas, RINHAS", "O valor limite das rinhas agora é 100k!")
        .addField("Inv e Status", "O Inventário e o Status agora estão em um comando só. Use `;inv` e veja seus itens. Reaja à mensagem e veja suas informações.")
        .setFooter(`${message.member.displayName} • Última atualização: 03/02/2019`, message.member.user.avatarURL)
        .setTimestamp();

    message.channel.send({
        embed
    })
}