exports.run = async (bot, message, args) => {
	let coolDowns = [3600000, 7200000, 10800000, 14400000, 21600000, 28800000, 3600000, 43200000, 64800000, 86400000, 144000000, 216000000, 259200000];

	const Discord = require("discord.js");

	let semana = 604800000; // 7 dias

	let target = message.mentions.members.first();
	let target2 = [];

	/*
	Para ver inventário sem pingar (funciona para outros servidores)
	> Se não tiver uma menção, ele irá pegar a string fornecida (espera-se o username do usuário) e irá procurar
	 em todo o banco de dados se há alguém com o user. Caso houver mais de um usuário com o mesmo username, ele
	 informará uma lista dos usuários junto de suas tags (username + discriminator). Se informar a tag, o usuário
	 será selecionado corretamente
	*/
	if (!target2[0] && args[0] && !target) { 

		let name = args.join(" ").toLowerCase();

		bot.users.forEach(item => {
			if (item.tag.toLowerCase() == name)
				target2.push(item);

			else if (item.username.toLowerCase() == name)
				target2.push(item);
		});

		if (!target2[0])
			return bot.createEmbed(message, "Usuário não encontrado.");

		if (target2.length > 1) {
			let str = ''
			for (let i = 0; i < target2.length; ++i)
				str += `**${target2[i].tag}**\n`;

			return bot.createEmbed(message, `Existem ${target2.length} usuários com o mesmo nome.\n${str}`);
		}
	}

	let alvo;

	if (target2.length > 0)
		alvo = target2[0];
	else {
		if (target)
			alvo = target.user;
		else
			alvo = message.author;
	}
	//let alvo = (target2.lenght > 0 ? target2[0] : (target ? target.user : message.author));
	/*
	Montagem do Inventário + Informações do usuário
	> Há dois embed, sendo o primeiro as informações básicas do inventário (armas, dinheiro, investimento e fichas)
	 e o segundo, estas mesmas informações com o acréscimo das informações do usuário (vitórias/derrotas no cassino, etc).
	> A opção de "abrir/fechar" o inventário ainda está um pouco bugada. Deve-se atualizar a função para ser recursiva.
	*/
	uData = bot.data.get(alvo.id)

	let time = new Date().getTime();

	if (!uData)
		return bot.createEmbed(message, "Este user não tem um inventário.");

	let total = 0;
	let currTime = new Date().getTime();

	bot.data.set(alvo.id, alvo.username, "nome");
	bot.data.set(alvo.id, alvo.tag, "tag");

	let texto_desc = '';

	if (uData.preso > time) texto_desc = `${bot.config.police} Preso por mais ${bot.minToHour((uData.preso - currTime) / 1000 / 60)}`;
	else if (uData.job >= 0) texto_desc = `${bot.config.bulldozer} Trabalhando por mais ${bot.minToHour((currTime - uData.jobTime - coolDowns[uData.job]) / 1000 / 60 * -1)}`;
	else texto_desc = `${bot.config.car} Vadiando`;

	const embed = new Discord.RichEmbed() // embed inv
		.setColor(message.member.displayColor)
		.setThumbnail("https://cdn.discordapp.com/attachments/531174573463306240/539877179786264634/inv1.png")
		.setAuthor("Inventário de " + alvo.username, alvo.avatarURL)
		.setColor(message.member.displayColor)

	const newEmbed = new Discord.RichEmbed() //embed status

	if (uData._knife > currTime) {
		embed.addField(bot.config.knife + " Faca", -Math.floor((currTime - uData._knife) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.knife + " Faca", -Math.floor((currTime - uData._knife) / 1000 / 60 / 60) + " Horas", true);
		total += 1;
	}

	if (uData._9mm > currTime) {
		embed.addField(bot.config._9mm + " 9mm", -Math.floor((currTime - uData._9mm) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config._9mm + " 9mm", -Math.floor((currTime - uData._9mm) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._tec9 > currTime) {
		embed.addField(bot.config.tec9 + " Tec9", -Math.floor((currTime - uData._tec9) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.tec9 + " Tec9", -Math.floor((currTime - uData._tec9) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._rifle > currTime) {
		embed.addField(bot.config.rifle + " Rifle", -Math.floor((currTime - uData._rifle) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.rifle + " Rifle", -Math.floor((currTime - uData._rifle) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._mp5 > currTime) {
		embed.addField(bot.config.mp5 + " MP5", -Math.floor((currTime - uData._mp5) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.mp5 + " MP5", -Math.floor((currTime - uData._mp5) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._ak47 > currTime) {
		embed.addField(bot.config.ak47 + " AK-47", -Math.floor((currTime - uData._ak47) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.ak47 + " AK-47", -Math.floor((currTime - uData._ak47) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._m4 > currTime) {
		embed.addField(bot.config.m4 + " M4", -Math.floor((currTime - uData._m4) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.m4 + " M4", -Math.floor((currTime - uData._m4) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._rpg > currTime) {
		embed.addField(bot.config.rpg + " RPG", -Math.floor((currTime - uData._rpg) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.rpg + " RPG", -Math.floor((currTime - uData._rpg) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._goggles > currTime) {
		embed.addField(bot.config.goggles + " Óculos V. Noturna", -Math.floor((currTime - uData._goggles) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.goggles + " Óculos V. Noturna", -Math.floor((currTime - uData._goggles) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._colete > currTime) {
		embed.addField(bot.config.colete + " Colete", -Math.floor((currTime - uData._colete) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.colete + " Colete", -Math.floor((currTime - uData._colete) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._minigun > currTime) {
		embed.addField(bot.config.minigun + " Minigun", -Math.floor((currTime - uData._minigun) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.minigun + " Minigun", -Math.floor((currTime - uData._minigun) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	if (uData._jetpack > currTime) {
		embed.addField(bot.config.jetpack + " Jetpack", -Math.floor((currTime - uData._jetpack) / 1000 / 60 / 60) + " Horas", true);
		newEmbed.addField(bot.config.jetpack + " Jetpack", -Math.floor((currTime - uData._jetpack) / 1000 / 60 / 60) + " Horas", true);

		total += 1;
	}

	/*if (uData.ficha > 0) {
		embed.addField(bot.config.ficha, uData.ficha.toLocaleString().replace(/,/g, ".") + " Fichas", true);
		total += 1;
	}

	if (uData.galo > 0) {
		embed.addField(":rooster:", (uData.galoNome != undefined ? uData.galoNome : 'Galo'), true);
		total += 1;
	}*/

	if (!(total % 2 == 0)) {
		embed.addBlankField(true);
		newEmbed.addBlankField(true);
	}

	//embed.addField("Grana:", uData.moni.toLocaleString().replace(/,/g, ".") + bot.config.coin, true);
	investimento = '';
	if (uData.invest != -1) {
		investimento += (` • ${(currTime < uData.investTime + semana ? bot.config.propertyG : bot.config.propertyR)} ` +
			(uData.invest == 0 ? "Boca de Fumo: " :
				(uData.invest == 1 ? "Puteiro: " :
					(uData.invest == 2 ? "Boate: " :
						(uData.invest == 3 ? "Clube de Golfe: " :
							(uData.invest == 4 ? "Cassino: " : "País do 3º Mundo: "))))) +
			(currTime < uData.investTime + semana ? -Math.floor((currTime - (uData.investTime + 604800000)) / 1000 / 60 / 60) + " Horas" :
				"Encerrado"))

	}
	embed.setDescription(bot.config.coin + " " + uData.moni.toLocaleString().replace(/,/g, ".") + investimento)
		.setFooter(`${message.member.displayName} • ${uData.ficha.toLocaleString().replace(/,/g, ".")} fichas`, message.member.user.avatarURL)
		.setTimestamp();

	newEmbed.setAuthor("Inventário de " + alvo.username, alvo.avatarURL)
		.setDescription(bot.config.coin + " " + uData.moni.toLocaleString().replace(/,/g, ".") + investimento)
		.setColor(message.member.displayColor)
		.setThumbnail('https://cdn.discordapp.com/attachments/531174573463306240/539877179786264634/inv1.png') //alvo.avatarURL)
		.addField(" 󠀀󠀀", texto_desc)
		.addField(bot.config.mafiaCasino + " Cassino", "Vitórias: `" + uData.betW.toLocaleString().replace(/,/g, ".") +
			"`\nDerrotas: `" + uData.betL.toLocaleString().replace(/,/g, ".") + "`", true)
		.addField(bot.config.emmetGun + " Roubos", "Sucessos: `" + uData.roubosW.toLocaleString().replace(/,/g, ".") +
			"`\nFracassos: `" + uData.roubosL.toLocaleString().replace(/,/g, ".") + "`", true)
		.addField(bot.config.bulldozer + " Ganhos em trabalhos", uData.jobGanhos.toLocaleString().replace(/,/g, ".") + bot.config.coin, true)
		.addField(bot.config.ammugun + " Gastos em loja", uData.lojaGastos.toLocaleString().replace(/,/g, ".") + bot.config.coin, true)
		.addField(bot.config.propertyG + " Lucros", uData.investGanhos.toLocaleString().replace(/,/g, ".") + bot.config.coin, true)
		.addField(`:rooster: ${uData.galoNome}`, "Nível: " + (uData.galoPower - 30), true)
		.setFooter(`${message.member.displayName} • ${uData.ficha.toLocaleString().replace(/,/g, ".")} fichas`, message.member.user.avatarURL)
		.setTimestamp();

		/*
		Reações
		> O bot irá reagir à mensagem do inventário. Se o usuário que chamou o comando clicar na reação, a mensagem
		 será editada para mostrar o segundo embed, as reações serão limpas e o bot irá reagir novamente, para "fechar"
		 o inventario.
		*/
	message.channel.send(embed)
		.then(msg => { // troca de página
			const reacao = msg.react('🔽').then(r => {

				msg.awaitReactions((reaction, user) => reaction.emoji.name == '🔽' && user.id == message.author.id, {
						time: 60000,
						max: 1
					})

					.then(collected => {
						r.remove(message.author.id);
						r.remove(bot.user.id);
						//msg.clearReactions();
						msg.edit(newEmbed).then(m => {
							msg.react('🔼').then(r => {

								msg.awaitReactions((reaction, user) => reaction.emoji.name == '🔼' && user.id == message.author.id, {
										time: 60000,
										max: 1
									})

									.then(collected => {
										r.remove(message.author.id);
										r.remove(bot.user.id);
										//msg.clearReactions();
										msg.edit(embed);
										//msg.react('🔽')
										return reacao;
									});
							});
						})
					});
			})

		})
}