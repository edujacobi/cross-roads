const Discord = require("discord.js");

exports.run = async (bot, message, args) => { //refazer pra ficar menor, separar em categorias
    const embed = new Discord.RichEmbed()
		.setTitle(bot.config.spray + " Grand Theft Auto: Discord Commands")
    	.setDescription("Commands that can be used in the bot")
		.setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/529168804291280897/GTAD.png")
		.setColor(message.member.displayColor)
		.addField("Buy",     	 "`" + bot.config.prefix + "store` : Open the store\n`" 
									 + bot.config.prefix + "buy [item ID ]` : Buy an item by its ID\n`"
									 + bot.config.prefix + "blackmarket` : Illegal products and dangerous work")
									  
		.addField("Work",   	 "`" + bot.config.prefix + "jobs` : Open the job's list\n`" 
								     + bot.config.prefix + "job [job ID]` : Start a job by its ID\n`" 
								     + bot.config.prefix + "stop` : Stop the job\n`" 
									 + bot.config.prefix + "income` : Receive payment for the job")

		.addField("Invest", 	 "`" + bot.config.prefix + "investments` : Open the investments list\n`" 
									 + bot.config.prefix + "invest [investments ID]` : Buy an investment\n`" 
									 + bot.config.prefix + "invest stop` : Abandons the current investment\n`" 
									 + bot.config.prefix + "income` : Receives profit related to investment time")
									 
		.addField("Rob",      	 "`" + bot.config.prefix + "rob info` : Shows more information on robberies\n`"
									 + bot.config.prefix + "rob user [user]` : Attempts to rob an user\n`"
									 + bot.config.prefix + "rob place [ID]` : Attempts to rob a place\n`"
									 + bot.config.prefix + "rob` : Shows your situation")

		.addField("Informations", "`" + bot.config.prefix + "topmoney (amount)` : Shows the richer users of server and global\n`" 
									 + bot.config.prefix + "topserver` : Show the rank of servers\n`"
									 + bot.config.prefix + "inv [user]` : Open the inventory and status of an user")

		.addField("Utilities",   "`" + bot.config.prefix + "daily` : Receive 250 daily\n`" 
									 + bot.config.prefix + "stats` : Show infos about the bot\n`"
									 + bot.config.prefix + "ping` : Verify the bot latency\n`"
									 + bot.config.prefix + "gift` : Receive a gift to start the game")			

		.addField("Gambling",    "`" + bot.config.prefix + "casino` : More infos about the games\n`"
									 + bot.config.prefix + "bet [head | tails] [value]` : Bet a value in Head or Tails\n`" 
									 + bot.config.prefix + "exchange [amount]` : Trade your chips for money\n`" 
									 + bot.config.prefix + "slot` : Slot machine with your chips\n`"
									 + bot.config.prefix + "rooster info` : Infos about Rooster fights\n`"
									 + bot.config.prefix + "roulette [number] [value]` : Play the Roulette. Choose a number from 0 to 36")
		.setFooter(message.author.username, message.member.user.avatarURL)
		.setTimestamp();
    message.channel.send({embed})
}
