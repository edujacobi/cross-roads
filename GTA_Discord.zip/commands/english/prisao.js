const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
	let keys = bot.data.indexes;
	let topArr = [];
	let nickArr = [];
	let topArr2 = [];
	let nickArr2 = [];
	let vezArr = [];
	let presos = [];
	let procurados = [];
	let currTime = new Date().getTime();


	for (let i = 0; i < keys.length; i++) {
		if (!message.guild.members.get(keys[i]))
			continue;
		if (!(keys[i] == bot.config.adminID)) {
			//nome = bot.data.get(keys[i], "nome").length > 25 ? bot.data.get(keys[i], "nome").substring(0, 22) + "..." : bot.data.get(keys[i], "nome");
			nome = bot.data.get(keys[i], "nome")
			if (bot.data.get(keys[i], "preso") > currTime) {
				presos[i] = {
					nick: nome,
					tempo: bot.data.get(keys[i], "preso") - currTime,
					vezes: bot.data.get(keys[i], "roubosL")
				};
			}
			if (bot.data.get(keys[i], "roubo") > currTime) {
				procurados[i] = {
					nick: nome,
					tempo: bot.data.get(keys[i], "roubo") - currTime,
				};
			}
		}
	}

	presos.sort(function (a, b) {
		return b.tempo - a.tempo;
	});
	procurados.sort(function (a, b) {
		return b.tempo - a.tempo;
	});


	for (let i = 0; i < keys.length; i++) { // mostra ou nao mostra
		if (presos[i]) {
			topArr[i] = presos[i].tempo;
			nickArr[i] = presos[i].nick;
			vezArr[i] = presos[i].vezes;
		}

		if (procurados[i]) {
			topArr2[i] = procurados[i].tempo;
			nickArr2[i] = procurados[i].nick;
		}
	}

	var topPreso = "";
	var topProcu = "";

	for (let i = 0; i < 10; ++i) {
		if (nickArr[i])
			topPreso = topPreso + (`**${nickArr[i]}**\nLivre em ${bot.minToHour((topArr[i] / 1000 / 60))}\nPreso ${vezArr[i]} vezes\n`);
		if (nickArr2[i])
			topProcu = topProcu + (`**${nickArr2[i]}**\nPor mais ${bot.minToHour((topArr2[i] / 1000 / 60))}\n`);
	}

	const embed = new Discord.RichEmbed()
		.setTitle("Prisão de " + message.guild.name)
		.setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/541052558832042024/radar_police.png")
		.setColor(message.member.displayColor)
		.addField("Detentos 👮", (topPreso == "" ? "Não há detentos." : topPreso), true)
		.addField("Procurados 🏃", (topProcu == "" ? "Não há procurados." : topProcu), true)

		.setFooter(message.author.username, message.member.user.avatarURL)
		.setTimestamp();
	message.channel.send({
		embed
	});
};

exports.help = {
	name: "base",
	category: "Code",
	description: "base",
	usage: "base",
	example: "base"
};