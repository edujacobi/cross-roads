const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
	const embed = new Discord.RichEmbed()

		.setTitle(bot.config.mafiaCasino + " Grand Theft Auto: Discord Casino")
		.setDescription("Bet, win, lose, break the bank!\nYou can bet your chips or your money!")
		.setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/529390152309538816/cassino-chip.png")
		.setColor(message.member.displayColor)
		.addField("Chips", "Buy chips at the store and use them at the slot machine and at roulette!")
		.addField("Head or Tails", "Betting a value in money, you have a 50% chance of winning or losing!\n" +
			"`" + bot.config.prefix + "bet [head | tails] [value]`")
		.addField("Battle roosters", "Your rooster starts at level 0, and with each win, it increases his level by 1. Each level further increases his chance of winning.\n" +
			"After each fight, your rooster should rest for 45min. The maximum bet amount is 100,000.\n" +
			"`" + bot.config.prefix + "rooster info`")
		.addField("Slot Machine", "Hit a trio and win 150! \nHIT A TRIO OF <:cash:539497634826551307> AND WIN 500!\n" +
			"`" + bot.config.prefix + "slot`")
		.addField("Roulette", "Bet on a number and hope to fall on yours! You get 36 times the bet! Choose numbers from 0 to 36.\n" +
			"`" + bot.config.prefix + "roulette [number] [value]`")
		.addField("Exchange", "Exchange your chips for money! Each chip is worth 90" + bot.config.coin + ".\n" +
			"`" + bot.config.prefix + "exchange [amount]`")
		.addField(bot.config.jetpack + " Jetpack", "This very expensive item increases your luck by 10%!\n*(Only working on Heads or Tails currently.)*")
		.setFooter(message.author.username, message.member.user.avatarURL)
		.setTimestamp();
	message.channel.send({
		embed
	});
}