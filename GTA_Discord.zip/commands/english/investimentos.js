const Discord = require("discord.js");
exports.run = async (bot, message, args) => {
    const embed = new Discord.RichEmbed()
    
        .setTitle(bot.config.propertyG + " Lugares para investir")
        .setDescription("Você receberá lucros a cada hora.\nCada investimento tem duração de 7 dias.\n\n")
        .setThumbnail("https://cdn.discordapp.com/attachments/333060149105131521/527535932581085184/golfclubicon.png")
        .setColor(message.member.displayColor)
    
        .addField("1: Boca de fumo",      `Valor: 10.000${bot.config.coin}\nLucro/h: 100${bot.config.coin}`, true)
        .addField("2: Puteiro",           `Valor: 50.000${bot.config.coin}\nLucro/h: 550${bot.config.coin}`, true)
        .addField("3: Boate",             `Valor: 150.000${bot.config.coin}\nLucro/h: 1.725${bot.config.coin}`, true)
        .addField("4: Clube de Golfe",    `Valor: 500.000${bot.config.coin}\nLucro/h: 6.000${bot.config.coin}`, true)
        .addField("5: Cassino",           `Valor: 1.500.000${bot.config.coin}\nLucro/h: 18.750${bot.config.coin}`, true)
        .addField("6: País do 3º mundo",  `Valor: 5.000.000${bot.config.coin}\nLucro/h: 65.000${bot.config.coin}`, true)
    
        .setFooter(message.author.username, message.member.user.avatarURL)
	    .setTimestamp();

    message.channel.send({embed})
}
