exports.run = (bot, message, args) => {
  const Discord = require('discord.js');
  const embed = new Discord.RichEmbed()

    .setTitle(bot.config.qmark + " Ajuda do Grand Theft Auto: Discord")
    .setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/529168804291280897/GTAD.png")
    .setColor(message.member.displayColor)

    .addField("Começando a jogar", "Crie seu usuário usando `" + bot.config.prefix + "inv`, e depois, use `" + bot.config.prefix +
      "presente`, para garantir um dinheirinho inicial.")
    .addField("Ganhando dinheiro", "Há muitas formas de ganhar dinheiro no jogo. Trabalhando, roubando, apostando ou investindo.")
    //.addField("Subindo de nível", "Quanto mais você trabalha, rouba, aposta e investe, mais experiência você acumula. (EM BREVE)")
    .addField("Comandos", "Para visualizar todos os comandos, utilize `" + bot.config.prefix + "comandos`")
    .setFooter(message.author.username, message.member.user.avatarURL)
    .setTimestamp();
  message.channel.send({
    embed
  })
};