let jobs = ["Entregador de panfleto", "Motoboy", "Pedreiro", "Açougueiro", "Vigilante", "Segurança Particular", "Caçador de Corno",
	"Treinador de milícia", "Mercenário", "Rei do Crime", "Homem-bomba", "Espião da Ordem", "Godfather da Mafia Nyanista"
];
let coolDowns = [3600000, 7200000, 10800000, 14400000, 21600000, 28800000, 3600000, 43200000, 64800000, 86400000, 144000000, 216000000, 259200000];

exports.run = async (bot, message, args) => {
	let date = new Date();
	let currTime = date.getTime();
	uData = bot.data.get(message.author.id)

	if (uData.preso > currTime) {
		let t = Math.floor((uData.preso - currTime) / 1000 / 60);
		return bot.createEmbed(message, `Você não pode trabalhar enquanto estiver preso. Sairá após ${bot.minToHour(t)}. :clock230:`);
	}

	if (!args[0]) {
		if (uData.job < 0 || !uData.jobTime)
			return bot.createEmbed(message, "Você não está trabalhando no momento. " + bot.config.bulldozer);

		let minutes = -Math.floor((currTime - uData.jobTime - coolDowns[uData.job]) / 1000 / 60);

		if (minutes < 0)
			return bot.createEmbed(message, "Você já terminou seu trabalho, já pode receber seu pagamento. " + bot.config.bulldozer);

		else
			return bot.createEmbed(message, `Faltam ${bot.minToHour(minutes)} para o término do seu trabalho. :clock230:`);

	}

	if (args[0] < 1 || (args[0] % 1 != 0) || args[0] > jobs.length)
		return bot.createEmbed(message, `O ID deve ser de 1 a ${jobs.length - 1}.`);
	else {
		if (args[0] == 4 && currTime > uData._knife)
			return bot.createEmbed(message, "É necessário ter uma " + bot.config.knife + " para este trabalho.");

		if (args[0] == 5 && currTime > uData._9mm)
			return bot.createEmbed(message, "É necessário ter uma " + bot.config._9mm + " para este trabalho.");

		if (args[0] == 6 && currTime > uData._tec9)
			return bot.createEmbed(message, "É necessário ter uma " + bot.config.tec9 + " para este trabalho.");

		if (args[0] == 7 && currTime > uData._rifle)
			return bot.createEmbed(message, "É necessário ter um " + bot.config.rifle + " para este trabalho.");

		if (args[0] == 8 && currTime > uData._mp5)
			return bot.createEmbed(message, "É necessário ter uma " + bot.config.mp5 + " para este trabalho.");

		if (args[0] == 9 && currTime > uData._ak47)
			return bot.createEmbed(message, "É necessário ter uma " + bot.config.ak47 + " para este trabalho.");

		if (args[0] == 10 && currTime > uData._m4)
			return bot.createEmbed(message, "É necessário ter uma " + bot.config.m4 + " para este trabalho.");

		if (args[0] == 11 && currTime > uData._rpg)
			return bot.createEmbed(message, "É necessário ter uma " + bot.config.rpg + " para este trabalho.");

		if (args[0] == 12 && currTime > uData._goggles)
			return bot.createEmbed(message, "É necessário ter um " + bot.config.goggles + " para este trabalho.");

		if (!bot.data.has(message.author.id, "_minigun"))
			uData._minigun = 0;

		if (args[0] == 13 && currTime > uData._minigun) {
			if (new Date().getDay() == 0 || new Date().getDay() == 6)
				return bot.createEmbed(message, "É necessário ter uma " + bot.config.minigun + " para este trabalho.");

			else
				return bot.createEmbed(message, "É necessário ser **Sábado** ou **Domingo** para este trabalho.");

		}

		if (currTime > (uData.jobTime + coolDowns[args[0] - 1]) || !uData.jobTime) {
			if (uData.job >= 0)
				bot.createEmbed(message, "Você precisa receber o salário antes de começar outro trabalho. " + bot.config.bulldozer);

			else {
				uData.job = args[0] - 1;
				uData.jobTime = currTime;
				bot.createEmbed(message, `Você começou a trabalhar de **${jobs[args[0] - 1]}**. ` + bot.config.bulldozer);
				
				setTimeout(function () {
					(message.reply("você terminou seu trabalho! " + bot.config.bulldozer))
				}, coolDowns[args[0] - 1]);
			}

		} else
			bot.createEmbed(message, "Você ainda está trabalhando. " + bot.config.bulldozer);

	}
	bot.data.set(message.author.id, uData)
}