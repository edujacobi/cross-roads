let invests = ["Boca de fumo", "Puteiro", "Boate", "Clube de Golfe", "Cassino", "País do 3º mundo"];
let semana = 604800000; // 7 dias
let prices = [10000, 50000, 150000, 500000, 1500000, 5000000];

exports.run = async (bot, message, args) => {
	uData = bot.data.get(message.author.id)

	let date = new Date();
	let currTime = date.getTime();

	if (uData.preso > currTime) {
		let t = Math.floor((uData.preso - currTime) / 1000 / 60);
		return bot.createEmbed(message, `Você não pode investir enquanto estiver preso. Sairá após ${bot.minToHour(t)} minutos. :clock230:`);
	}

	if (args[0] == "parar") {
		if (uData.invest == -1)
			return bot.createEmbed(message, "Você não pode parar um investimento que não existe.");
		else {
			bot.createEmbed(message, "Você parou o investimento " + invests[uData.invest] + ".");
			uData.investLast = 0;
			uData.invest = -1;
			uData.investTime = 0;
		}


	} else if (args[0] < 1 || (args[0] % 1 != 0) || args[0] > invests.length)
		return bot.createEmbed(message, `O ID deve ser de 1 a ${invests.length}.`);

	else if (uData.invest >= 0)
		return bot.createEmbed(message, "Você só pode ter um investimento por vez.");

	else if (uData.moni < prices[args[0] - 1])
		return bot.createEmbed(message, `Você não possui ${bot.config.coin} suficiente para comprar este investimento.`);

	else {
		if (currTime > (uData.investTime + semana) || !uData.investTime) {
			uData.invest = args[0] - 1;
			uData.investTime = currTime;
			uData.investLast = currTime;
			bot.createEmbed(message, message.author.username + " comprou o investimento **" + invests[args[0] - 1] + "**.");
			uData.moni -= prices[args[0] - 1];
		}
	}
	bot.data.set(message.author.id, uData)
}