const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
    const embed = new Discord.RichEmbed()
        //.setTitle("Convites")
        .setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/529168804291280897/GTAD.png")
        .setColor(message.member.displayColor)

        .addField("<:propertyG:539497344996212736> Coloque o GTA Discord no seu servidor", "https://discordapp.com/oauth2/authorize?client_id=526203502318321665&permissions=8&scope=bot")
        .addField("<:GTAD2:529879187381551104> Entre no servidor do GTA Discord", "http://discord.gg/sNf8avn")

        .setFooter(message.author.username, message.member.user.avatarURL)
        .setTimestamp();

    message.channel.send({
        embed
    })
}