exports.run = async (bot, message, args) => {
	let uData = bot.data.get(message.author.id);

	if (uData.ficha < 1) 
		return bot.createEmbed(message, `You don't have ${bot.config.ficha} to exchange.`);

	else if (args[0] <= 0 || (args[0] % 1 != 0)) 
		return bot.createEmbed(message, "The inserted value is invalid.");

	else {
		if (parseFloat(uData.ficha) < args[0]) 
			return bot.createEmbed(message, `You don't have this amount of ${bot.config.ficha} to exchange.`);
		
		valor = args[0];
		cambio = valor * 90; // cada ficha vale 90 no câmbio
		uData.ficha = uData.ficha - valor;
		uData.moni = uData.moni + cambio;
		bot.createEmbed(message, `You exchanged ${valor.toLocaleString().replace(/,/g, ".")} ${bot.config.ficha} by ${cambio}${bot.config.coin}.`);
	}
	bot.data.set(message.author.id, uData);
};

exports.help = {
	name: "base",
	category: "Code",
	description: "base",
	usage: "base",
	example: "base"
};