const Discord = require("discord.js");
exports.run = async (bot, message, args) => {
    const embed = new Discord.RichEmbed()

        .setTitle(bot.config.saveGame + " Update 0.18 Carnaval")
        .setThumbnail("https://cdn.discordapp.com/attachments/453314806674358292/526265639552417802/GTD.png")
        .setColor(message.member.displayColor)
                .addField("Informações de armas", "Veja informações úteis de cada arma usando `;arma [nome]`.")
                .addField("VINGANÇA!", "Agora você receberá uma notificação se alguém tentar lhe roubar sem sucesso.")
                .addField("Perca tudo no seu galo", "Limite de aposta da rinha removido!")
                .addField("Perca tudo no cara ou coroa", "Ao usar `;bet [cara|coroa] allin`, todo seu dinheiro será apostado!")
                .addField(":new: Carnaval", "Mercado Negro estará aberto durante ~~todo ocarnaval~~ toda a semana!")

        .setFooter(`${message.author.username} • Última atualização: 02/03/2019`, message.member.user.avatarURL)
        .setTimestamp();

    message.channel.send({
        embed
    })
}