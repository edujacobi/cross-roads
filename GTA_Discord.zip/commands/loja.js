const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
	uData = bot.data.get(message.author.id);
    const embed = new Discord.RichEmbed()
	
		.setTitle(bot.config.ammugun + " Grand Theft Auto: Discord Shop")
		.setDescription("Todos os itens tem duração de 3 dias")
		//.setThumbnail("https://cdn.discordapp.com/attachments/462656263109476353/467339132163719183/Soco_na_sua_cara.png")
    	.setColor(message.member.displayColor)
	
		.addField(`1: ${bot.config.knife} Faca`, 				`Preço: 2.000${bot.config.coin} \nATK +10\nDEF +5`, true)
		.addField(`2: ${bot.config._9mm} 9mm`, 					`Preço: 7.000${bot.config.coin} \nATK +20\nDEF +10`, true)
		.addField(`3: ${bot.config.tec9} Tec9`, 				`Preço: 20.000${bot.config.coin} \nATK +30\nDEF +15`, true)
		.addField(`4: ${bot.config.rifle}  Rifle`,				`Preço: 30.000${bot.config.coin} \nATK +45\nDEF +15`, true)
		.addField(`5: ${bot.config.mp5} Mp5`, 					`Preço: 42.000${bot.config.coin} \nATK +40\nDEF +20`, true)
		.addField(`6: ${bot.config.ak47} AK-47`, 				`Preço: 62.000${bot.config.coin} \nATK +50\nDEF +25`, true)
		.addField(`7: ${bot.config.m4} M4`, 					`Preço: 92.000${bot.config.coin} \nATK +60\nDEF +35`, true)
		.addField(`8: ${bot.config.rpg} RPG`, 					`Preço: 128.000${bot.config.coin} \nATK +70\nDEF + 40`, true)
		.addField(`9: ${bot.config.goggles} Óculos V Noturna`, 	`Preço: 250.000${bot.config.coin} \nATK +10\nDEF +50`, true)
		.addField(`10: ${bot.config.colete} Colete`, 			`Preço: 1.000.000${bot.config.coin} \nATK +0\nDEF +70`, true)
		.addField(`11: ${bot.config.jetpack} Jetpack`, 			`Preço: 2.000.000${bot.config.coin} \nFuga +10`, true)
		.addField(`12: ${bot.config.whey} Whey Protein`,		(bot.data.has(message.author.id, "galo") ? 
																		(uData.galoPower >= 70 ? "Seu pinto já tá grande." :   
																		"Preço: " + ((((uData.galoPower - 29)*10)**2).toLocaleString().replace(/,/g, "."))  + bot.config.coin + "\nAumenta o nível do galo\nPreço para **" + (uData.nome.length > 12 ? uData.nome.substring(0, 10) + "...**" : `${uData.nome}**`)) : "Primeiro, use `;galo`."), true)
		.addField(`13: ${bot.config.ficha} 10 Fichas`,			`Preço: 1.000${bot.config.coin} \nPara usar no cassino`, true)
		.addField(`14: ${bot.config.ficha} 100 Fichas`,			`Preço: 9.900${bot.config.coin} \nUma é por conta da casa`, true)
		.addBlankField(true)
		.setFooter(message.author.username, message.member.user.avatarURL)
		.setTimestamp();	
    message.channel.send({embed});
}
