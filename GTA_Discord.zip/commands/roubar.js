function getPercent(percent, from) {
	return (from / 100) * percent;
}
const Discord = require("discord.js");

exports.run = async (bot, message, args) => {
	let time = new Date().getTime();
	let option = args[0];
	uData = bot.data.get(message.author.id)
	let userD = uData;

	if (option == "info") {
		const embed = new Discord.RichEmbed()
			.setTitle(bot.config.emmetGun + " Informações sobre roubos")
			.setThumbnail("https://cdn.discordapp.com/attachments/529674667414519810/530730684613132328/9mm.png")
			.setColor(message.member.displayColor)
			.addField("Roubo à pessoas", "Adquira um alvo, e roube tudo dele!\n" +
				"Quanto melhor a sua arma, mais quantidade de dinheiro pode ser roubada (e mais será protegido, caso você seja assaltado).\n" +
				"Caso você falhe, você ficará preso por um tempo determinado pelo poder da sua arma.\n" +
				"Caso tenha sucesso, você deverá esperar 1h para assaltar novamente\n" +
				"`" + bot.config.prefix + "roubar pessoa [usuário]`")
			.addField("1: Velhinha na esquina",
				"Chance de sucesso: 75%\n" +
				"Necessário: " + bot.config.knife +
				"\n80 - 300" + bot.config.coin, true)
			.addField("2: Mercearia do Zé",
				"Chance de sucesso: 65%\n" +
				"Necessário: " + bot.config._9mm +
				"\n1.200 - 1.700" + bot.config.coin, true)
			.addField("3: Posto de gasolina",
				"Chance de sucesso: 55%\n" +
				"Necessário: " + bot.config.tec9 +
				"\n4.000 - 6.500" + bot.config.coin, true)
			.addField("4: Banco da cidade",
				"Chance de sucesso: 45%\n" +
				"Necessário: " + bot.config.ak47 +
				"\n9.000 - 23.000" + bot.config.coin, true)
			.addField("5: Máfia Nyanista",
				"Chance de sucesso: 35%\n" +
				"Necessário: " + bot.config.rpg +
				"\n40.000 - 70.000" + bot.config.coin, true)
			.addField("Roubo à lugares", "	`" + bot.config.prefix + "roubar lugar [ID]`", true)

			.setFooter(message.author.username, message.member.user.avatarURL)
			.setTimestamp();
		return message.channel.send(embed);
	}
	if (userD.preso > time) {
		let t = Math.floor((userD.preso - time) / 1000 / 60);
		return bot.createEmbed(message, `Você não pode roubar enquanto está preso. Sairá após ${bot.minToHour(t)}. :clock230:`)
	}
	if (userD.roubo > time) {
		let t = Math.floor((userD.roubo - time) / 1000 / 60);
		return bot.createEmbed(message, `Você só poderá roubar novamente após ${bot.minToHour(t)}. :clock230:`)
	}

	if (option == "lugar") {
		let locais = [
			80, 300,
			1200, 1700,
			4000, 6500,
			9000, 23000,
			40000, 70000
		];
		if (args[1] < 1 || (args[1] % 1 != 0) || args[1] > (locais.length) / 2)
			return bot.createEmbed(message, `Insira um ID de 1 a ${locais.length/2}.`);

		else {
			if (args[1] == 1 && time > uData._knife)
				return bot.createEmbed(message, "É necessário ter uma " + bot.config.knife + " para este roubo.");

			if (args[1] == 2 && time > uData._9mm)
				return bot.createEmbed(message, "É necessário ter uma " + bot.config._9mm + " para este roubo.");

			if (args[1] == 3 && time > uData._tec9)
				return bot.createEmbed(message, "É necessário ter uma " + bot.config.tec9 + " para este roubo.");

			if (args[1] == 4 && time > uData._ak47)
				return bot.createEmbed(message, "É necessário ter um " + bot.config.ak47 + " para este roubo.");

			if (args[1] == 5 && time > uData._rpg)
				return bot.createEmbed(message, "É necessário ter uma " + bot.config.rpg + " para este roubo.");
		}

		if (userD.job >= 0) return bot.createEmbed(message, "Você não pode roubar enquanto estiver trabalhando! " + bot.config.bulldozer);

		let chances = [75, 65, 55, 45, 35];
		let tempos = [20, 40, 60, 120, 160]
		let lugares = [
			'Velhinha na esquina', 'Mercearia do Zé', 'Posto de gasolina', 'Banco da cidade', 'Mafia Nyanista'
		]

		prob = (bot.getRandom(0, 100) < chances[args[1] - 1] ? "win" : "lose");

		if (prob == "win") {
			recompensa = bot.getRandom(locais[(args[1] * 2) - 2], locais[(args[1] * 2) - 1]);
			uData.roubosW++;
			uData.roubo = time + 3600000;
			uData.moni += recompensa;
			bot.createEmbed(message, `Você roubou ${recompensa.toLocaleString().replace(/,/g, ".")}${bot.config.coin} de **${lugares[args[1] - 1]}**. :gun:`);

		} else {
			uData.roubosL++;
			uData.preso = time + tempos[args[1] - 1] * 60 * 1000;
			bot.createEmbed(message, `Você falhou ao roubar o(a) **${lugares[args[1] - 1]}** e ficará preso por ${bot.minToHour(tempos[args[1] - 1])} minutos. :oncoming_police_car:`);
		}

	} else if (option == "pessoa") {
		let target = message.mentions.members.first();
		let target2 = [];

		if (!target2[0] && args[1] && !target) { // para ver inventário sem pingar (funciona para outros servidores)

			let name = args.join(" ").replace(args[0], "").replace(" ", "").toLowerCase();

			bot.users.forEach(item => {
				if (item.tag.toLowerCase() == name)
					target2.push(item);

				else if (item.username.toLowerCase() == name)
					target2.push(item);
			});

			if (!target2[0])
				return bot.createEmbed(message, "Usuário não encontrado.");

			if (target2.length > 1) {
				let str = ''
				for (let i = 0; i < target2.length; ++i)
					str += `**${target2[i].tag}**\n`;

				return bot.createEmbed(message, `Existem ${target2.length} usuários com o mesmo nome.\n${str}`);
			}
		}

		let alvo;

		if (target2.length > 0)
			alvo = target2[0];
		else {
			if (target)
				alvo = target.user;
			else
				alvo = message.author;
		}
		//let alvo = (target ? target.user : message.author);

		if (!target && !target2[0])
			return bot.createEmbed(message, "Você deve inserir um usuário a ser roubado.")

		let targetD = bot.data.get(alvo.id)
		if (!target) target = target2[0];

		if (!targetD) return bot.createEmbed(message, "Este usuário não tem um inventário.");
		if (userD.job >= 0) return bot.createEmbed(message, "Você não pode roubar enquanto estiver trabalhando! " + bot.config.bulldozer);

		// ordem Power: knife, goggles, 9mm, tec9, rifle, mp5, ak47, m4 e rpg (colete é nulo) + Minigun
		// ordem Def: knife, 9mm, tec9, rifle, mp5, ak47, m4, rpg, goggles e colete + Minigun
		let powerPercents = [0, 10, 10, 20, 30, 45, 40, 50, 60, 70, 80];
		let defPercents =   [5, 10, 15, 15, 20, 25, 35, 40, 50, 70, 55];
		//					 0	 1	 2	 3	 4	 5	 6	 7	 8	 9  10
		let moneyAttack =   [0,  6,  6, 12, 18, 24, 30, 36, 40, 46, 49];
		let moneyDef =      [3,  6,  9, 12, 15, 18, 21, 24, 27, 30, 33];

		let uIndex = -1; // usado pra definir atk
		let tIndex = -1; // usado pra definir def

		if (userD._colete > time) uIndex = 0; // ATK 0  DEF 70
		if (userD._knife > time) uIndex = 1; // ATK 10 DEF 5
		if (userD._goggles > time) uIndex = 2; // ATK 10 DEF 50
		if (userD._9mm > time) uIndex = 3; // ATK 20 DEF 10
		if (userD._tec9 > time) uIndex = 4; // ATK 30 DEF 15
		if (userD._rifle > time) uIndex = 5; // ATK 45 DEF 15
		if (userD._mp5 > time) uIndex = 6; // ATK 40 DEF 20
		if (userD._ak47 > time) uIndex = 7; // ATK 50 DEF 25
		if (userD._m4 > time) uIndex = 8; // ATK 60 DEF 35
		if (userD._rpg > time) uIndex = 9; // ATK 70 DEF 40
		if (userD._minigun > time) uIndex = 10; // ATK 80 DEF 55

		if (targetD._knife > time) tIndex = 0; // ATK 10 DEF 5
		if (targetD._9mm > time) tIndex = 1; // ATK 20 DEF 10
		if (targetD._tec9 > time) tIndex = 2; // ATK 30 DEF 15
		if (targetD._rifle > time) tIndex = 3; // ATK 45 DEF 15
		if (targetD._mp5 > time) tIndex = 4; // ATK 40 DEF 20
		if (targetD._ak47 > time) tIndex = 5; // ATK 50 DEF 25
		if (targetD._m4 > time) tIndex = 6; // ATK 60 DEF 35
		if (targetD._rpg > time) tIndex = 7; // ATK 70 DEF 40
		if (targetD._goggles > time) tIndex = 8; // ATK 10 DEF 50
		if (targetD._minigun > time) tIndex = 9; // ATK 80 DEF 55
		if (targetD._colete > time) tIndex = 10; // ATK 0  DEF 70


		if (uIndex < 0) return bot.createEmbed(message, "Você não pode roubar desarmado.");
		if (tIndex >= 0) powerPercents[uIndex] -= getPercent(defPercents[tIndex], powerPercents[uIndex]);

		if (message.author.id == target.id)
			return bot.createEmbed(message, "Você não pode roubar a si próprio.");

		if (target.id == bot.config.adminID)
			return bot.createEmbed(message, "Você não pode fazer isso.");

		if (bot.getRandom(0, 100) < powerPercents[uIndex]) {
			if (tIndex >= 0) moneyAttack[uIndex] -= getPercent(moneyDef[tIndex], moneyAttack[uIndex]);

			let money = Math.floor(getPercent(moneyAttack[uIndex], targetD.moni));
			let chips = Math.floor((getPercent(moneyAttack[uIndex], targetD.ficha)) / 2);

			bot.createEmbed(message, `Você conseguiu roubar ${money.toLocaleString().replace(/,/g, ".")} ${bot.config.coin} ` +
				(targetD.ficha > 0 ? `e ${chips.toLocaleString().replace(/,/g, ".")} ${bot.config.ficha} ` : "") + `de **${alvo.username}**. :gun: `);
			
			bot.users.get(target.id).send(`Você foi roubado, perdeu ${money.toLocaleString().replace(/,/g, ".")} ${bot.config.coin} ` +
				(targetD.ficha > 0 ? `e ${chips.toLocaleString().replace(/,/g, ".")} ${bot.config.ficha} ` : "") + `pro **${message.author.username}** do servidor **${message.guild.name}**. :gun: `)

			targetD.moni -= money;
			targetD.ficha -= chips;
			uData.moni += money;
			uData.ficha += chips;
			uData.roubosW++;
			uData.roubo = time + 3600000;
			setTimeout(function () {
				(message.reply("você já pode roubar novamente! :gun:"))
			}, 3600000);

		} else {
			bot.createEmbed(message, `Você falhou na tentativa, ficará preso por ${bot.minToHour(20 * (uIndex + 1))}. :oncoming_police_car: `);
			uData.preso = time + (20 * (uIndex + 1)) * 60 * 1000;
			uData.roubosL++;

			bot.users.get(target.id).send(`**${message.author.username}** de **${message.guild.name}** tentou lhe roubar mas acabou sendo preso. ${bot.config.police}`)

			setTimeout(function () {
				(message.reply("você está livre! :oncoming_police_car:"))
			}, uData.preso - time);

		}
		bot.data.set(target.id, targetD)
	} else
		return bot.createEmbed(message, 'Você deve escolher "pessoa" ou "lugar". Para mais informações, use `;roubar info`.');
	bot.data.set(message.author.id, uData)

}