exports.run = async (bot, message, args) => {
	let time = new Date().getTime();
	let uData = bot.data.get(message.author.id);
	if (uData.job >= 0) return bot.createEmbed(message, "Você não pode apostar enquanto estiver trabalhando. " + bot.config.bulldozer);

	if (uData.preso > time) {
		let t = Math.floor((uData.preso - time) / 1000 / 60);
		return bot.createEmbed(message, `Você não pode apostar enquanto estiver preso. Sairá após ${bot.minToHour(t)}. :clock230: `);
	}

	
	if (args[1] == 'allin')
		args[1] = uData.moni;

	if (uData.moni < 1)
		return bot.createEmbed(message, `Você não tem ${bot.config.coin} suficiente para apostar.`);

	else if (args[1] <= 0 || (args[1] % 1 != 0))
		return bot.createEmbed(message, "O valor inserido não é válido.");

	else if (args[0] == "cara" || args[0] == "coroa") {
		message.delete();
		
		

		if (parseFloat(uData.moni) < args[1])
			return bot.createEmbed(message, "Você não tem esse valor para apostar.");

		let flip;

		flip = (bot.getRandom(0, 100) < 50 ? "cara" : "coroa");

		if (args[0] == flip) {
			uData.moni += parseInt(args[1]);
			uData.betW++;
			bot.createEmbed(message, `Você **ganhou** ${parseInt(args[1]).toLocaleString().replace(/,/g, ".")} e ficou com ` + (uData.moni.toLocaleString().replace(/,/g, ".")) + bot.config.coin + ".");

		} else {
			uData.moni -= parseInt(args[1]);
			uData.betL++;
			bot.createEmbed(message, `Você **perdeu** ${parseInt(args[1]).toLocaleString().replace(/,/g, ".")} e ficou com ` + (uData.moni.toLocaleString().replace(/,/g, ".")) + bot.config.coin + ".");
		}

	} else {
		bot.createEmbed(message, "Você deve apostar em cara ou coroa.");
		return;
	}
	bot.data.set(message.author.id, uData);
}