module.exports = async bot => {
  bot.user.setActivity(`${bot.data.indexes.length} users! Update 0.18!`, {type: "LISTENING"});
  console.log('pronto')
};
