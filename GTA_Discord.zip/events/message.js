module.exports = (bot, message) => {
  if (message.author.bot)
    return;

  if (message.channel.type == 'dm')
    return;

  if (!message.isMentioned(bot.user) && !message.content.startsWith(bot.config.prefix))
    return;

  const args = message.content.slice(bot.config.prefix.length).trim().split(/ +/g);
  const command = args.shift().toLowerCase();

  var key = message.author.id;
  bot.data.ensure(key, bot.defaultCarteira);

  const cmd = bot.commands.get(command);

  if (!cmd)
    return;

  message.flags = [];

  while (args[0] && args[0][0] === "-")
    message.flags.push(args.shift().slice(1));

  console.log(`log: ${message.content} | ${message.author.username} | ${message.guild.name} | ${message.channel.name}`);

  cmd.run(bot, message, args);
};